"""Domain models for the search service."""
