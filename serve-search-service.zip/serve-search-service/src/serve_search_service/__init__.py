"""Search service package."""
